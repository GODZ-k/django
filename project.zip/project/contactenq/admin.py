from django.contrib import admin
from contactenq.models import contactenq

class contact_det(admin.ModelAdmin):
    list_display=('name','email','subject','message')

admin.site.register(contactenq,contact_det)
# Register your models here.
