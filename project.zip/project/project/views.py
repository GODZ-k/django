from django.http import HttpResponse,HttpResponseRedirect
from service.models import service

from django.shortcuts import render
import math
from django.core.paginator import Paginator
from news.models import news
from contactenq.models import contactenq

# def home(request):
#     dict={
#      'title':'home page',
#       'val':'hello',
#      'list':['php','java','python'],
#      'numlist':[10,20,30,40],
#     #  'numlist':[],
#      'slist':[
#         {'name':'rahul','phone':1212121212},
#         {'name':'tanmay','phone':1212121212},
#         {'name':'tanmay1','phone':1212121212},
#         {'name':'tanmay2','phone':1212121212},
#         {'name':'tanmay2','phone':1212121212},
#         {'name':'tanmay3','phone':1212121212},
#         {'name':'tanmay4','phone':1212121212},

#         {'name':'tanmay5','phone':1212121212}]
#     }
#     return render(request,"index.html",dict)
# dict={
#         'title':'bubble game '   for global use
#     }
# def home(request):
#     dict={
#         'title':'bubble game'
#     }
#     return render(request,"index.html",dict)
def home(request):
    newsdata=news.objects.all()
    servicedata=service.objects.all()#.order_by('-service_title')[:8] # order_by is used for ascending or dercending the tablw data based on ''service_titile,service_icon ect (model keys) | with - decending nd withour ascending
    # for a in servicedata:
    paginatordata=Paginator(servicedata,2)
    page_number=request.GET.get('page')
    finaldata=paginatordata.get_page(page_number)
    totalpages=finaldata.paginator.num_pages

    #  print(a.service_icon)
    # print(service)
    if request.method=="GET":
       x=request.GET.get('servicename')
       if x!=None:
          servicedata=service.objects.filter(service_title__icontains=x)
    fetch={
      #  'servicedata':servicedata,
       'servicedata':finaldata,
       'lastpage':totalpages,
       'newsdata':newsdata,
       'totalpage_no':[n+1 for n in range(totalpages)]
    }
    return render(request,"index.html",fetch)
def detail(request,slug):
  #  if request.method=='GET':
  newsdetail=news.objects.get(news_slug=slug)
  data={
     'newsdetail':newsdetail
  }


  return render(request,'detail.html',data)


def blog(request):
    return render(request,"blog.html")


# def aboutus(request):
#     return HttpResponse("<h1>hello</h1>")

def about(request):
    return render(request,'about.html')

# def contact(request):
      # return render(request,'contact.html')

def contact(request):   #def saveenqform(request) for get the data form the GETl to the next page
       n=''
       if request.method=='POST':
          name=request.POST.get('name')
          email=request.POST.get('email')
          subject=request.POST.get('subject')
          message=request.POST.get('message')

          sendform=contactenq(name=name,email=email,subject=subject,message=message)
          sendform.save()
          n='form is submitted'

       return render(request,'contact.html',{'n':n})



def cart(request):
    return render(request,'cart.html')

def shop(request):
    return render(request,'shop.html')
# for redirect the form data on next page ---------------
def getdata(request):
#    if request.method=="GET":
#       output=request.GET['output']
#    return render(request,"getdata.html",{'output':output})
   # it is imp before defination in try and catch
    try:
     if request.method=='POST':
    #  a=int(request.GET['num1'])
    #  b=int(request.GET['num2'])
      c=int(request.POST['num1'])
      d=int(request.POST['num2'])
      data3=c+d

      return HttpResponse(data3)  # for action in form .
    except:
    #    print("can not accesss")_
     pass


# def form(request):
#     data1=0
#     try:
#      a=int(request.GET['num1'])
#      b=int(request.GET['num2'])
#      data1=a+b
#     except:
#         pass

#     return render(request,'form.html',{'data':data1})

#  get data from the form via get method ---------

# def form(request):
#     data1=0
#     x={}  # it is imp before defination in try and catch
#     try:
#      if request.method=='POST':
#     #  a=int(request.GET['num1'])
#     #  b=int(request.GET['num2'])
#       a=int(request.POST['num1'])
#       b=int(request.POST['num2'])
#       data1=a+b
#      x={
#         'n1':a,
#         'n2':b,
#         'finalresult':data1
#      }
#      url="/getdata/?output={}".format(data1)
#      return HttpResponseRedirect(url)  #/getdata/

#     except:
#     #    print("can not accesss")_
#      pass
#     return render(request,'form.html',x)  #{'data':data1}
# def aboutusdetail(request,courseid):
#     return HttpResponse(courseid)


# django calculator ---------------------------------

# def form(request):
#     c=0
#     x={}
#     try:
#      if request.method=='POST':
#         a=eval(request.POST['number1'])
#         b=eval(request.POST['number2'])
#         c=request.POST['option']
#         if c=="+":
#            c=a+b
#         elif c=="-":
#            c=a-b
#         elif c=="*":
#            c=a*b
#         elif c=="/":
#            c=a/b
#         x={
#               'n1':a,
#               'n2':b,
#               'c':c

#         }
#     except:
#       c='invalid'

#     return render(request,'form.html',x)

# django odd even identifier--------------------------

# def form(request):
#     c=""
#     x={}
#     try:
#       if request.method=='POST':
#         a=eval(request.POST['data1'])
#         if a%2==0:
#           c="even"
#         else:
#           c="odd"
#         x={
#            'a':a,
#            'output':c
#         }

#     except:
#        pass

#     return render(request,'form.html',x)

# create simple marksheet form ------------
# def form(request):
#     # x=0
#     # y=0
#     # p=0

#     dict={}
#     z=""
#     try:
#       if request.method=='POST':
#         a=eval(request.POST['num-1'])
#         b=eval(request.POST['num-2'])
#         c=eval(request.POST['num-3'])
#         d=eval(request.POST['num-4'])
#         e=eval(request.POST['num-5'])
#         x=a+b+c+d+e
#         y=x*100/500
#         p=math.floor(y)
#         if p>=60:
#             z="First"
#         elif p<70 and p>=40:
#             z="Second"
#         elif p<40 and p>=33:
#             z="Third"
#         else:
#             z="Fail"

#         dict={
#             'n1':a,
#             'n2':b,
#             'n3':c,
#             'n4':d,
#             'n5':e,
#             'output1':x,
#             'output2':p,
#             'output3':z
#         }
#     except:
#      "invalid"


#     return render(request,'form.html',dict)

# mannual form validation

def form(request):
    c=""
    x={}
    try:
      if request.method=='POST':
        if request.POST['data1']=="":
           return render(request,'form.html',{'error':True})

        a=eval(request.POST['data1'])
        if a%2==0:
          c="even"
        else:
          c="odd"
        x={
           'a':a,
           'output':c
        }

    except:
       pass

    return render(request,'form.html',x)

